package sk.kosak.kos0333.gamingcenter;

import com.mysql.cj.PreparedQuery;
import com.mysql.cj.jdbc.result.ResultSetMetaData;
import jdk.jfr.Frequency;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet(name = "GamingServlet", value = "/GamingServlet")
public class GamingServlet extends HttpServlet {
    Connection connection = null;
    Map<String, String> userInfoStorage = new HashMap<>();

    @Override
    public void init() throws ServletException {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/rezervacnisluzbavlaku", "root", "root");
            System.out.println("Successfully connected to the database.");
        } catch (SQLException e) {
            System.out.println("There was a problem connecting to the database.");
            e.printStackTrace();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String formParam = "";
        if (request.getParameter("games") != null) {
            formParam = request.getParameter("games");
        }
        switch (formParam) {
            case "Slot machine":
                List<Integer> numbersFormachine = new ArrayList<>();
                request.setAttribute("telephonenumber", request.getParameter("telephonenumber"));
                request.setAttribute("balance", request.getParameter("balance"));
                if (request.getParameter("play") != null) {
                    if (request.getParameter("telephonenumber") != null) {
                        numbersFormachine = playSlotMachine();
                        System.out.println("2 winwin 1 win 0 lose: " + numbersFormachine.get(3));
                        if (numbersFormachine.get(3) == 2) {
                            changeBalance(request, (Double.parseDouble(request.getParameter("money"))) * (Double.parseDouble(request.getParameter("money"))));
                            request.setAttribute("balance", getBalance(request));
                        } else if (numbersFormachine.get(3) == 1) {
                            changeBalance(request, Double.parseDouble(request.getParameter("money")));
                            request.setAttribute("balance", getBalance(request));
                        } else {
                            changeBalance(request, (-Double.parseDouble(request.getParameter("money"))));
                            request.setAttribute("balance", getBalance(request));
                        }
                    }
                    for (int i = 0; i < 3; i++) {
                        System.out.println("Číslo " + (i + 1) + " ; " + numbersFormachine.get(i));
                    }
                    System.out.println("Výhra: " + getBalance(request) + " +/- " + request.getParameter("money"));
                    request.setAttribute("number1", numbersFormachine.get(0));
                    request.setAttribute("number2", numbersFormachine.get(1));
                    request.setAttribute("number3", numbersFormachine.get(2));

                    request.setAttribute("moneySelected", request.getParameter("money"));
                    request.getRequestDispatcher("slotMachine.jsp").forward(request, response);
                } else {
                    request.setAttribute("userInformation", request.getParameter("userInformation"));
                    request.getRequestDispatcher("slotMachine.jsp").forward(request, response);
                }
                break;
            case "Guess number":
                Random random = new Random();
                int randomNumber = random.nextInt(10);
                if (request.getParameter("play") != null) {
                    if (userInfoStorage.size()!=0) {
                        System.out.println("TELEPHONE " + userInfoStorage.size());
                        System.out.println("TELEPHONE " + userInfoStorage.size());
                        System.out.println("TELEPHONE " + userInfoStorage.size());
                        System.out.println("TELEPHONE " + request.getParameter("telephonenumber"));
                        if (randomNumber == (Integer.parseInt(request.getParameter("number")))) {
                            changeBalance(request, (Double.parseDouble(request.getParameter("money"))) + (Double.parseDouble(request.getParameter("money"))));
                            request.setAttribute("balance", getBalance(request) + (Double.parseDouble(request.getParameter("money"))) * (Double.parseDouble(request.getParameter("money"))));
                        } else {
                            changeBalance(request, -Double.parseDouble(request.getParameter("money")));
                            request.setAttribute("balance", getBalance(request) - Integer.parseInt(request.getParameter("money")));
                        }
                    }
                    request.setAttribute("balance", getBalance(request));
                    request.setAttribute("moneySelected", request.getParameter("money"));
                    request.setAttribute("telephonenumber", userInfoStorage.get("telephonenumber"));
                    request.setAttribute("numberToGuess", randomNumber);
                    request.getRequestDispatcher("guessNumber.jsp").forward(request, response);
                } else {
                    request.setAttribute("balance", getBalance(request));
                    request.setAttribute("telephonenumber", userInfoStorage.get("telephonenumber"));
                    request.getRequestDispatcher("guessNumber.jsp").forward(request, response);
                }
                break;
            case "Go back to title page":
                request.setAttribute("userInformation", userInfoStorage);
                request.getRequestDispatcher("gamingCenter.jsp").forward(request, response);
                break;
            default:
                request.getRequestDispatcher("gamingCenter.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        String formParam = "";
        if (request.getParameter("form") != null) {
            formParam = request.getParameter("form");
        }
        switch (formParam) {
            case "registration":
                System.out.println("Registration attempt.");
                Enumeration<String> listOfParams = request.getParameterNames();
                Map<String, String> parameterValues = new HashMap<>();
                while (listOfParams.hasMoreElements()) {
                    String paramName = listOfParams.nextElement();
                    parameterValues.put(paramName, request.getParameter(paramName));
                }
                if (isPhoneNumberCopy(parameterValues) || isFormEmpty(parameterValues) || isParameterShort(parameterValues)) {
                    System.out.println("Mistake in form was found.");
                    for (String key : parameterValues.keySet()) {
                        request.setAttribute(key, parameterValues.get(key));
                    }
                    request.setAttribute("errorRegistration", "Please double check length of name, surname and password. Make sure the whole form is filled up. Make sure your phone number is not in use already.");
                    request.getRequestDispatcher("login.jsp").forward(request, response);
                } else {
                    System.out.println("Form was filled up correctly, adding user to the database.");
                    insertUserIntoDatabase(parameterValues);
                    request.setAttribute("phoneLog", parameterValues.get("phoneReg"));
                    request.setAttribute("passwordLog", parameterValues.get("passwordReg"));
                    request.getRequestDispatcher("login.jsp").forward(request, response);
                    break;
                }
            case "login":
                if (login(request)) {
                    request.setAttribute("userInformation", userInformation(request));
                    userInfoStorage = userInformation(request);
                    System.out.println(userInformation(request));
                    request.getRequestDispatcher("gamingCenter.jsp").forward(request, response);
                } else {
                    request.setAttribute("errorLogin", "Your log in information was incorrect.");
                    request.setAttribute("phoneLog", request.getParameter("phoneLog"));
                    request.setAttribute("passwordLog", request.getParameter("passwordLog"));
                    request.getRequestDispatcher("login.jsp").forward(request, response);
                }
            case "Delete account":
                System.out.println(request.getParameter("telephonenumber"));
                if (request.getParameter("telephonenumber") != null) {
                    deleteAccount(request.getParameter("telephonenumber"));
                    request.getRequestDispatcher("index.jsp").forward(request, response);
                }
                break;
            case "Add balance":
                request.setAttribute("userInformation", userInfoStorage);
                addBalance(request);
                request.getRequestDispatcher("gamingCenter.jsp").forward(request, response);
        }
    }

    public void addBalance(HttpServletRequest request) {
        try {
            String sqlquery = "UPDATE gamingcentre.user SET balance = " + (Double.parseDouble(userInfoStorage.get("balance")) + Double.parseDouble(request.getParameter("moneyBalance"))) + " WHERE telephonenumber = \"" + userInfoStorage.get("telephonenumber") + "\";";

            PreparedStatement addBalance = connection.prepareStatement(sqlquery);

            addBalance.executeUpdate();

            userInfoStorage.put("balance", ("" + (Double.parseDouble(userInfoStorage.get("balance")) + Double.parseDouble(request.getParameter("moneyBalance")))));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteAccount(String telephonenumber) {
        try {
            String sqlquery = "DELETE from gamingcentre.user WHERE telephonenumber = \"" + telephonenumber + "\";";

            PreparedStatement deleteUser = connection.prepareStatement(sqlquery);

            deleteUser.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Map<String, String> userInformation(HttpServletRequest request) {
        Map<String, String> userInformation = new HashMap<>();
        try {
            String sqlquery = "SELECT * FROM gamingcentre.user WHERE telephonenumber = \"" + request.getParameter("phoneLog") + "\"";

            Statement selectInfo = connection.createStatement();

            ResultSet resultSet = selectInfo.executeQuery(sqlquery);

            resultSet.next();

            ResultSetMetaData resultSetMetaData = (ResultSetMetaData) resultSet.getMetaData();

            for (int i = 1; i <= resultSetMetaData.getColumnCount(); i++) {
                userInformation.put(resultSetMetaData.getColumnName(i), resultSet.getString(resultSetMetaData.getColumnName(i)));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return userInformation;
    }

    @Override
    public void destroy() {
        try {
            connection.close();
            System.out.println("Successfully closed database connection.");
        } catch (SQLException ex) {
            ex.printStackTrace();
            System.err.println("Database wasn't closed successfully.");
        }
    }

    public boolean isPhoneNumberCopy(Map<String, String> parameterValues) {
        boolean isCopy = false;
        try {
            String sqlquery = "SELECT * FROM gamingcentre.user WHERE telephonenumber = \"" + parameterValues.get("phoneReg") + "\"";

            Statement selectCopy = connection.createStatement();
            ResultSet resultSet = selectCopy.executeQuery(sqlquery);
            if (resultSet.next() && resultSet.getString("telephonenumber").equals(parameterValues.get("phoneReg"))) {
                isCopy = true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return isCopy;
        }
        return isCopy;
    }

    public boolean isFormEmpty(Map<String, String> parameterValues) {
        boolean isEmpty = false;
        for (String value : parameterValues.values()) {
            if (value.trim().equals("")) {
                isEmpty = true;
            }
        }
        return isEmpty;
    }

    public boolean isParameterShort(Map<String, String> parameterValues) {
        boolean isShort = false;
        if (parameterValues.get("nameReg").length() < 2 || parameterValues.get("surnameReg").length() < 2 || parameterValues.get("passwordReg").length() < 3) {
            isShort = true;
        }
        return isShort;
    }

    public void insertUserIntoDatabase(Map<String, String> parameterValues) {
        try {
            String sqlquery = "INSERT INTO gamingcentre.user (cardnumber, password, surname, telephonenumber, email, name, authentication) VALUES(?,?,?,?,?,?,?)";

            PreparedStatement insertUser = connection.prepareStatement(sqlquery);
            System.out.println(parameterValues);
            parameterValues.remove("registration");
            int i = 1;
            for (String key : parameterValues.keySet()) {
                if (i < 7) {
                    insertUser.setString(i, parameterValues.get(key));
                }
                if (i == 7 && (parameterValues.get(key).equals("on"))) {
                    insertUser.setInt(7, 1);
                } else {
                    insertUser.setInt(7, 0);
                }
                i++;
            }

            insertUser.executeUpdate();
            System.out.println("User was successfully added to the database.");
        } catch (SQLException e) {
            System.out.println("There was a problem adding user to the database.");
            e.printStackTrace();
        }
    }

    public boolean login(HttpServletRequest request) {
        boolean isCorrect = false;
        try {
            String sqlquery = "SELECT * FROM gamingcentre.user WHERE telephonenumber = \"" + request.getParameter("phoneLog") + "\"";

            Statement selectUser = connection.createStatement();

            ResultSet resultSet = selectUser.executeQuery(sqlquery);

            if (resultSet.next() && resultSet.getString("password").equals(request.getParameter("passwordLog"))) {
                isCorrect = true;
            }
            return isCorrect;
        } catch (SQLException e) {
            e.printStackTrace();
            return isCorrect;
        }
    }

    public List<Integer> playSlotMachine() {
        List<Integer> listForMachine = new ArrayList<>();
        Random random = new Random();
        for (int i = 0; i < 3; i++) {
            listForMachine.add(random.nextInt(10));
        }
        System.out.println("List for machine 1. : " + listForMachine);
        if (listForMachine.get(0) == listForMachine.get(1) && listForMachine.get(0) == listForMachine.get(2)) {
            listForMachine.add(2);
            System.out.println("List for machine v 2. : " + listForMachine);

        } else if (listForMachine.get(0) == listForMachine.get(1)) {
            listForMachine.add(1);
            System.out.println("List for machine v 1. : " + listForMachine);
        } else if(listForMachine.get(0) == listForMachine.get(2)){
            listForMachine.add(1);
            System.out.println("List for machine v 1. : " + listForMachine);
        }
        else {listForMachine.add(0);
            System.out.println("List for machine v 0. : " + listForMachine);}
        System.out.println("List for machine 2. : " + listForMachine);
        System.out.println("List for machine 2. : " + listForMachine);
        return listForMachine;
    }

    public void changeBalance(HttpServletRequest request, double money) {
        try {
            String sqlquery = "UPDATE gamingcentre.user SET balance = " + (getBalance(request) + money) + " WHERE (`telephonenumber` = \'" + request.getParameter("telephonenumber") + "\');";
            PreparedStatement updateBalance = connection.prepareStatement(sqlquery);

            updateBalance.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Integer getBalance(HttpServletRequest request) {
        Integer userBalance = null;
        try {
            String sqlquery = "SELECT * FROM gamingcentre.user WHERE telephonenumber = \"" + request.getParameter("telephonenumber") + "\";";

            Statement selectBalance = connection.createStatement();

            ResultSet resultSet = selectBalance.executeQuery(sqlquery);

            resultSet.next();

            userBalance = resultSet.getInt("balance");

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return userBalance;
    }
}

