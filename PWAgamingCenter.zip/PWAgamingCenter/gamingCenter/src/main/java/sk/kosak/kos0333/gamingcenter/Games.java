package sk.kosak.kos0333.gamingcenter;

public enum Games {
    SLOT_MACHINE("Slot machine"),
    GUESS_NUMBER("Guess number");

    public String gameName;

    Games(String gameName){
        this.gameName = gameName;
    }

    public String getGameName() {
        return gameName;
    }
}